module WordCount2 {
}